#ifndef LOGFILE_H
#define LOGFILE_H
#include "cpu.hpp"
void logValues(FILE* file, RISCV_cpu *cpu, pipeline* pipe);
#endif
